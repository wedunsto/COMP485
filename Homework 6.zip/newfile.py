'''this is a sample code
hw6 question4'''
a = [2,4,6,8,10] # this is a list 

for i in a:
	print(i)
#print()
